-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Bulan Mei 2020 pada 03.48
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(35) NOT NULL,
  `admin_password` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'admin', '123123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_global`
--

CREATE TABLE `data_global` (
  `dg_id` int(11) NOT NULL,
  `dg_country` varchar(50) NOT NULL,
  `dg_pos` int(11) NOT NULL,
  `dg_healed` int(11) NOT NULL,
  `dg_died` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_global`
--

INSERT INTO `data_global` (`dg_id`, `dg_country`, `dg_pos`, `dg_healed`, `dg_died`) VALUES
(4, 'US', 1212123, 189791, 71526),
(5, 'Spain', 219329, 123486, 25613),
(6, 'Italy', 214457, 93245, 29684),
(7, 'United Kingdom', 202355, 926, 30150),
(8, 'France', 170694, 52859, 25538),
(9, 'Germany', 168162, 139900, 7275);

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_lokal`
--

CREATE TABLE `data_lokal` (
  `dl_id` int(11) NOT NULL,
  `dl_age` int(3) NOT NULL,
  `dl_gender` varchar(20) NOT NULL,
  `dl_stats` varchar(15) NOT NULL,
  `dl_states` varchar(75) NOT NULL,
  `dl_hospital` varchar(100) NOT NULL,
  `dl_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_lokal`
--

INSERT INTO `data_lokal` (`dl_id`, `dl_age`, `dl_gender`, `dl_stats`, `dl_states`, `dl_hospital`, `dl_date`) VALUES
(18, 222222, 'female', 'neg', 'Riau', 'rs', '2020-04-10'),
(19, 12, 'male', 'pos', 'Sumatera Barat', '-', '2020-05-06'),
(20, 22, 'female', 'pos', 'Bali', '-', '2020-05-06'),
(21, 44, 'male', 'pos', '-', '-', '2020-05-04'),
(22, 21, '-', 'pos', 'Sumatera Selatan', '-', '2020-04-27'),
(23, 21, '-', 'pos', 'Sumatera Selatan', '-', '2020-04-27'),
(24, 1, '-', 'neg', '-', '-', '2020-05-07'),
(25, 2, '-', 'neg', '-', '-', '2020-04-28'),
(26, 43, '-', 'pos', '-', '-', '2020-05-02'),
(28, 44, '-', 'pos', '-', '-', '2020-05-05'),
(29, 33, '-', 'pos', '-', '-', '2020-04-07'),
(30, 54, '-', 'pos', '-', '-', '2020-04-06'),
(31, 33, '-', 'pos', '-', '-', '2020-03-03'),
(32, 12, '-', 'pos', '-', '-', '2020-04-18'),
(33, 33, '-', 'pos', '-', '-', '2020-05-06'),
(34, 44, '-', 'pos', '-', '-', '2020-05-05'),
(35, 14, '-', 'healed', '-', '-', '2020-05-05'),
(36, 22, '-', 'healed', '-', '-', '2020-04-28'),
(37, 12, '-', 'healed', '-', '-', '2020-04-27'),
(38, 33, '-', 'healed', '-', '-', '2020-04-26'),
(39, 45, '-', 'died', '-', '-', '2020-04-07'),
(40, 65, '-', 'died', '-', '-', '2020-04-17'),
(42, 25, '-', 'pos', '-', '-', '2020-05-05'),
(43, 66, '-', 'died', '-', '-', '2020-05-04'),
(45, 22, 'male', 'pos', 'DKI Jakarta', 'RSPI Dr. Sulianti Saroso', '2020-05-18'),
(46, 19, 'male', 'pos', 'Jawa Barat', 'RSU Dr. Hasan Sadikin Bandung', '2020-05-03'),
(47, 12, 'female', 'pos', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-05-03'),
(48, 31, 'female', 'pos', 'Jawa Barat', 'RSU Dr. Hasan Sadikin Bandung', '2020-04-23'),
(49, 24, 'male', 'neg', 'Sulawesi Tengah', 'RSUD Sulteng', '2020-04-29'),
(50, 69, 'female', 'pos', 'Banten', 'RSUD Serang', '2020-04-23'),
(51, 23, 'male', 'pos', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-05-01'),
(52, 21, 'female', 'pos', 'Jawa Barat', 'RSU Dr. Hasan Sadikin Bandung', '2020-05-02'),
(53, 121, 'female', 'pos', 'Jawa Barat', ' RSUD Gunung Jati Cirebon', '2020-04-09'),
(54, 51, 'male', 'pos', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-04-22'),
(55, 45, 'female', 'pos', '-', 'RSU Dr. Hasan Sadikin Bandung', '2020-05-05'),
(56, 22, 'female', 'pos', 'Sumatera Barat', 'RSUD Tarakan', '2020-04-01'),
(57, 45, 'male', 'neg', 'Sumatera Utara', 'RSUD Tarakan', '2020-03-26'),
(58, 43, 'female', 'healed', 'Sumatera Utara', 'RSUD Tarakan', '2020-04-06'),
(59, 23, 'male', 'pos', 'Jawa Barat', 'RSUP Fatmawati', '2020-05-07'),
(60, 62, 'male', 'neg', 'Jawa Timur', 'RSUP Fatmawati', '2020-04-01'),
(61, 34, 'female', 'healed', 'Jawa Barat', 'RSUD Tarakan', '2020-03-26'),
(62, 23, 'female', 'pos', 'Jawa Barat', 'RSUP Fatmawati', '2020-03-02'),
(63, 34, 'male', 'pos', 'Jawa Barat', 'RSUD Tarakan', '2020-03-19'),
(64, 76, 'female', 'neg', 'Jawa Barat', 'RSUP Fatmawati', '2020-03-26'),
(65, 14, 'male', 'pos', 'Jawa Barat', 'RSUD Tarakan', '2020-03-19'),
(66, 68, 'female', 'neg', 'Jawa Barat', 'RSUP Fatmawati', '2020-03-12'),
(67, 86, 'male', 'neg', 'Jawa Barat', 'RSUP Fatmawati', '2020-04-04'),
(68, 45, 'male', 'pos', 'Jawa Barat', 'RSUD Tarakan', '2020-05-06'),
(69, 55, 'male', 'neg', 'DKI Jakarta', 'RSUP Fatmawati', '2020-05-20'),
(70, 44, 'male', 'healed', 'DKI Jakarta', 'RSUD Tarakan', '2020-05-06'),
(71, 65, 'male', 'died', 'DKI Jakarta', 'RSUP Fatmawati', '2020-03-20'),
(72, 13, 'male', 'neg', 'DKI Jakarta', 'RSUD Tarakan', '2020-05-07'),
(73, 32, 'female', 'died', 'Jawa Tengah', 'RSU Persahabatan', '2020-04-30'),
(74, 23, 'female', 'healed', 'DKI Jakarta', 'RSUD Tarakan', '2020-04-23'),
(75, 24, 'male', 'neg', 'Jawa Barat', '. RSU Persahabatan', '2020-04-28'),
(76, 56, 'male', 'neg', 'DI Yogyakarta', 'RSU Persahabatan', '2020-04-14'),
(77, 34, 'male', 'healed', 'DI Yogyakarta', '. RSU Persahabatan', '2020-04-15'),
(78, 23, 'male', 'pos', 'Bali', '. RSU Persahabatan', '2020-04-29'),
(79, 23, 'male', 'pos', 'DKI Jakarta', '. RSU Persahabatan', '2020-04-26'),
(80, 54, 'male', 'neg', 'Jawa Timur', 'RSU Persahabatan', '2020-04-26'),
(81, 34, 'male', 'neg', 'Jawa Tengah', '. RSU Persahabatan', '2020-04-28'),
(82, 65, 'male', 'died', 'Jawa Barat', '. RSU Persahabatan', '2020-04-29'),
(83, 34, 'male', 'died', 'Jawa Timur', 'RSU Persahabatan', '2020-05-02'),
(84, 23, 'male', 'neg', 'Banten', 'RSU Persahabatan', '2020-05-01'),
(85, 55, 'male', 'healed', 'DKI Jakarta', 'RSU Persahabatan', '2020-04-30'),
(86, 43, 'male', 'healed', 'Jawa Tengah', 'RSUD Tarakan', '2020-04-29'),
(87, 35, 'female', 'neg', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-04-30'),
(88, 25, 'male', 'neg', 'DKI Jakarta', 'RSUD Tarakan', '2020-04-27'),
(89, 64, 'male', 'neg', 'Jawa Tengah', 'RSU Persahabatan', '2020-04-26'),
(90, 46, 'male', 'pos', 'DKI Jakarta', 'RSAL Mintoharjp', '2020-04-09'),
(91, 46, 'male', 'died', 'Jawa Barat', 'RSUD Tarakan', '2020-04-22'),
(92, 46, 'male', 'pos', 'Jawa Barat', 'RSAL Mintoharjp', '2020-05-06'),
(93, 34, 'male', 'healed', 'Jawa Timur', 'RSAL Mintoharjp', '2020-04-15'),
(94, 12, 'female', 'pos', 'Nanggroe Aceh Darussalam', 'RSPI Dr. Sulianti Saroso', '2020-02-05'),
(95, 31, 'male', 'neg', 'Jawa Barat', 'RSPI Dr. Sulianti Saroso', '2020-02-05'),
(96, 32, 'female', 'neg', 'Jambi', 'RSPI Dr. Sulianti Saroso', '2020-04-29'),
(97, 12, 'male', 'pos', 'Jawa Timur', 'RSUD Tarakan', '2020-04-28'),
(98, 43, 'male', 'healed', 'Bali', 'RSUP Fatmawati', '2020-04-30'),
(99, 34, 'female', 'neg', 'DI Yogyakarta', 'RSUD Kab. Indramayu', '2020-04-28'),
(100, 35, 'male', 'neg', 'DI Yogyakarta', 'RSUD Kab. Indramayu', '2020-04-15'),
(101, 35, 'male', 'pos', 'DKI Jakarta', 'RSUP Fatmawati', '2020-04-02'),
(102, 23, 'male', 'pos', 'Jawa Barat', 'RSUP Fatmawati', '2020-04-08'),
(103, 34, 'female', 'healed', 'Jawa Barat', 'RSUP Fatmawati', '2020-04-29'),
(104, 35, 'male', 'pos', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-04-30'),
(105, 75, 'male', 'pos', 'DKI Jakarta', 'RSUP Fatmawati', '2020-04-01'),
(106, 86, 'female', 'died', 'Gorontalo', 'RSUD Tarakan', '2020-05-20'),
(107, 76, 'male', 'pos', 'Nanggroe Aceh Darussalam', 'RSUP Fatmawati', '2020-04-15'),
(108, 45, 'male', 'neg', 'DI Yogyakarta', 'RSUP Fatmawati', '2020-04-16'),
(109, 35, 'male', 'pos', 'Jawa Timur', 'RSUD Tarakan', '2020-05-06'),
(110, 34, 'male', 'died', 'Bali', 'RSUP Fatmawati', '2020-04-28'),
(111, 54, 'female', 'neg', 'Kepulauan Riau', 'RSUP Fatmawati', '2020-04-17'),
(112, 16, 'male', 'neg', 'Jawa Tengah', 'RSUP Fatmawati', '2020-05-13'),
(113, 46, 'male', 'neg', 'DI Yogyakarta', 'RSUD Kab. Indramayu', '2020-05-04'),
(114, 64, 'male', 'healed', 'Bali', 'vRSUP Fatmawati', '2020-05-05'),
(115, 46, 'male', 'neg', 'Bali', ' RSAL Mintoharjp', '2020-05-20'),
(116, 43, 'female', 'healed', 'Jawa Barat', 'RSUD Kab. Indramayu', '2020-04-02'),
(117, 43, 'male', 'died', 'Kalimantan Selatan', ' RSAL Mintoharjp', '2020-04-15'),
(118, 34, 'female', 'died', 'Jawa Tengah', ' RSAL Mintoharjp', '2020-05-13'),
(119, 24, 'male', 'healed', 'Nusa Tenggara Barat', ' RSAL Mintoharjp', '2020-05-21'),
(120, 54, 'male', 'died', 'Jawa Timur', ' RSAL Mintoharjp', '2020-05-12'),
(121, 23, 'male', 'pos', 'Bali', 'RSUD Tarakan', '2020-04-16'),
(122, 54, 'male', 'neg', 'Nusa Tenggara Timur', ' RSAL Mintoharjp', '2020-04-15'),
(123, 25, 'female', 'died', 'DI Yogyakarta', ' RSAL Mintoharjp', '2020-05-07'),
(124, 54, 'male', 'neg', 'DI Yogyakarta', ' RSAL Mintoharjp', '2020-05-06'),
(125, 24, 'female', 'neg', 'Sulawesi Tengah', ' RSAL Mintoharjp', '2020-04-30'),
(126, 97, 'male', 'pos', 'Bengkulu', 'RSUD Pasar Rebo', '2020-05-05'),
(127, 76, 'male', 'neg', 'Sumatera Selatan', 'RSUD Pasar Rebo', '2020-04-28'),
(128, 67, 'female', 'neg', 'Jawa Timur', 'RSUD Pasar Rebo', '2020-05-11'),
(129, 56, 'male', 'neg', 'Jawa Tengah', 'RSUD Tarakan', '2020-04-01'),
(130, 67, 'male', 'healed', 'Kalimantan Barat', 'RSUD Pasar Rebo', '2020-04-27'),
(131, 45, 'male', 'neg', '-', 'RSUD Pasar Rebo', '2020-05-07'),
(132, 34, 'male', 'died', 'Bali', 'RSUD Pasar Rebo', '2020-04-29'),
(133, 23, 'female', 'died', 'Nusa Tenggara Barat', 'RSUD Kab. Indramayu', '2020-04-28'),
(134, 32, 'male', 'healed', 'Jawa Barat', 'RSUD Tarakan', '2020-04-27'),
(135, 23, 'female', 'healed', 'Kepulauan Bangka Belitung', 'RSUD Kab. Indramayu', '2020-04-30'),
(136, 52, 'male', 'neg', 'Jambi', 'RSUD Kab. Indramayu', '2020-04-10'),
(137, 24, 'male', 'healed', 'Riau', 'RSUP Fatmawati', '2020-04-29'),
(138, 54, 'male', 'neg', 'Jawa Barat', 'RSUP Fatmawati', '2020-04-16'),
(139, 46, 'female', 'neg', 'Lampung', 'RSUD Tarakan', '2020-04-15'),
(140, 57, 'male', 'healed', 'Sumatera Barat', 'RSUP Fatmawati', '2020-04-16'),
(141, 78, 'female', 'healed', 'Sulawesi Tenggara', 'RSUP Fatmawati', '2020-05-20'),
(142, 65, 'male', 'healed', 'Nusa Tenggara Barat', 'RSUP Fatmawati', '2020-05-05'),
(143, 46, 'male', 'healed', 'Nusa Tenggara Barat', 'RSUP Fatmawati', '2020-05-14'),
(144, 46, 'male', 'neg', 'Kalimantan Barat', 'RSUP Fatmawati', '2020-05-06'),
(145, 57, 'male', 'neg', 'DKI Jakarta', 'RSUP Fatmawati', '2020-05-13'),
(146, 23, 'male', 'died', 'DKI Jakarta', 'RSUP Fatmawati', '2020-05-04'),
(147, 35, 'female', 'died', 'Jawa Tengah', 'RSUP Fatmawati', '2020-05-12'),
(148, 35, 'female', 'healed', 'Jawa Tengah', 'RSUP Fatmawati', '2020-05-06'),
(149, 63, 'female', 'neg', 'Jawa Tengah', 'RSUP Fatmawati', '2020-05-06'),
(150, 64, 'female', 'pos', 'Nusa Tenggara Barat', 'RSUP Fatmawati', '2020-05-06'),
(151, 64, 'male', 'healed', 'DI Yogyakarta', 'RSUP Fatmawati', '2020-04-24'),
(152, 43, 'male', 'pos', 'Bali', 'RSUP Fatmawati', '2020-05-14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotlines`
--

CREATE TABLE `hotlines` (
  `hl_id` int(11) NOT NULL,
  `hl_number` varchar(15) NOT NULL,
  `hl_name` varchar(75) NOT NULL,
  `hl_img` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `hotlines`
--

INSERT INTO `hotlines` (`hl_id`, `hl_number`, `hl_name`, `hl_img`) VALUES
(5, '0215210411', 'Kementrian Kesehatan', 'hi2kxQSwLS.png'),
(6, '081212123119', 'Kementrian Kesehatan', 'SCj5W3Bcyw.png'),
(7, '112', 'Pemprov DKI Jakarta', 'QUBBeq7kuY.png'),
(8, '081388376955', 'Pemprov DKI Jakarta', 'X3iY6kR3DC.png'),
(9, '0243580713', 'Pemprov Jawa Tengah', '4u8Jd4br3L.png'),
(10, '082313600560', 'Pemprov Jawa Tengah', '9I7RoPneF4.png'),
(11, '0318430313', 'Pemprov Jawa Timur', 'UuUicveI88.png'),
(12, '081334367800', 'Pemprov Jawa Timur', 'KFycZHfULj.png'),
(13, '119', 'Pemprov Jawa Barat', 'CJz11kHb94.png'),
(14, '0811-209-3306', 'Pemprov Jawa Barat', 'gEXEM7IxH3.png'),
(18, '0274555585', 'Pemprov D.I Yogyakarta', 'nj6sKmBCEi.png'),
(19, '0811-2764-800', 'Pemprov D.I Yogyakarta', '80uLI0N6gh.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan`
--

CREATE TABLE `pesan` (
  `msg_id` int(11) NOT NULL,
  `msg_name` varchar(75) NOT NULL,
  `msg_email` varchar(55) NOT NULL,
  `msg_text` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pesan`
--

INSERT INTO `pesan` (`msg_id`, `msg_name`, `msg_email`, `msg_text`) VALUES
(3, 'john doe', 'john@doe.com', 'tes 123\r\n');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indeks untuk tabel `data_global`
--
ALTER TABLE `data_global`
  ADD PRIMARY KEY (`dg_id`);

--
-- Indeks untuk tabel `data_lokal`
--
ALTER TABLE `data_lokal`
  ADD PRIMARY KEY (`dl_id`);

--
-- Indeks untuk tabel `hotlines`
--
ALTER TABLE `hotlines`
  ADD PRIMARY KEY (`hl_id`);

--
-- Indeks untuk tabel `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`msg_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `data_global`
--
ALTER TABLE `data_global`
  MODIFY `dg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `data_lokal`
--
ALTER TABLE `data_lokal`
  MODIFY `dl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT untuk tabel `hotlines`
--
ALTER TABLE `hotlines`
  MODIFY `hl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `pesan`
--
ALTER TABLE `pesan`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
