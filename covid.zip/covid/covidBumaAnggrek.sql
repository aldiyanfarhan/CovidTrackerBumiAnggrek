-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2021 at 07:24 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(35) NOT NULL,
  `admin_password` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'admin', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `data_global`
--

CREATE TABLE `data_global` (
  `dg_id` int(11) NOT NULL,
  `dg_country` varchar(50) NOT NULL,
  `dg_pos` int(11) NOT NULL,
  `dg_healed` int(11) NOT NULL,
  `dg_died` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_global`
--

INSERT INTO `data_global` (`dg_id`, `dg_country`, `dg_pos`, `dg_healed`, `dg_died`) VALUES
(23, 'DKI Jakarta', 420459, 405971, 7002),
(24, 'Jawa Barat', 301003, 268333, 7002),
(25, 'Jawa Tengah', 191588, 175917, 8862),
(26, 'Jawa Timur', 151931, 138990, 11099),
(27, 'Kalimantan Timur', 70404, 67616, 1691),
(28, 'Sulawesi Selatan', 61795, 60554, 936),
(29, 'Riau', 52696, 47271, 1382),
(30, 'Banten', 48563, 45672, 1236),
(31, 'Bali', 46555, 43817, 1335),
(32, 'Daerah Istimewa Yogyakarta', 42524, 39098, 1088);

-- --------------------------------------------------------

--
-- Table structure for table `data_lokal`
--

CREATE TABLE `data_lokal` (
  `dl_id` int(11) NOT NULL,
  `dl_age` int(3) NOT NULL,
  `dl_gender` varchar(20) NOT NULL,
  `dl_stats` varchar(15) NOT NULL,
  `dl_states` varchar(75) NOT NULL,
  `dl_hospital` varchar(100) NOT NULL,
  `dl_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_lokal`
--

INSERT INTO `data_lokal` (`dl_id`, `dl_age`, `dl_gender`, `dl_stats`, `dl_states`, `dl_hospital`, `dl_date`) VALUES
(156, 15, 'male', 'healed', 'GH', 'Rumah', '2021-04-21'),
(157, 23, 'male', 'healed', 'JKL', 'RSUD Kota Bekasi', '2021-04-07'),
(158, 23, 'male', 'healed', 'PQ', 'RSUD Kota Bekasi', '2021-04-14'),
(159, 23, 'male', 'healed', 'GH', 'Rumah', '2021-04-20'),
(160, 25, 'male', 'healed', 'GH', 'Rumah', '2021-04-20'),
(161, 35, 'female', 'healed', 'GH', 'Rumah', '2021-04-20'),
(162, 40, 'male', 'died', 'JKL', 'RSUD Kota Bekasi', '2021-04-21'),
(163, 50, 'female', 'healed', 'JKL', 'RSUD Kota Bekasi', '2021-04-21'),
(164, 36, 'female', 'healed', 'MN', 'RSUD Kota Bekasi', '2021-04-21'),
(165, 41, 'male', 'healed', 'PQ', 'GOR Bekasi', '2021-04-22'),
(166, 36, 'male', 'healed', 'RS', 'GOR Bekasi', '2021-05-22'),
(167, 37, 'female', 'healed', 'RS', 'Wisma Atlet', '2021-04-23'),
(168, 28, 'male', 'healed', 'X', 'Wisma Atlet', '2021-04-23'),
(169, 18, 'female', 'healed', 'Y', 'Wisma Atlet', '2021-04-23'),
(170, 21, 'male', 'healed', 'Y', 'Wisma Atlet', '2021-04-23'),
(171, 28, 'female', 'healed', 'TU', 'Rumah', '2021-04-24'),
(172, 24, 'male', 'healed', 'Z', 'Rumah', '2021-04-25'),
(173, 22, 'male', 'healed', 'Z', 'Rumah', '2021-04-26'),
(174, 53, 'male', 'died', 'GH', 'RSUD Kota Bekasi', '2021-04-25'),
(175, 45, 'male', 'died', 'GH', 'RSUD Kota Bekasi', '2021-04-25'),
(176, 15, 'female', 'healed', 'JKL', 'Rumah', '2021-04-25'),
(177, 35, 'female', 'healed', 'PQ', 'Rumah', '2021-04-26'),
(178, 40, 'male', 'healed', 'RS', 'Wisma Atlet', '2021-04-26'),
(179, 54, 'male', 'died', 'X', 'RSUD Kota Bekasi', '2021-04-26'),
(180, 55, 'male', 'healed', 'X', 'RSUD Kota Bekasi', '2021-04-26'),
(181, 20, 'female', 'healed', 'MN', 'Wisma Atlet', '2021-04-27'),
(182, 41, 'female', 'healed', 'RS', 'Wisma Atlet', '2021-04-27'),
(183, 24, 'female', 'healed', 'RS', 'GOR Bekasi', '2021-04-27'),
(184, 26, 'female', 'healed', 'TU', 'GOR Bekasi', '2021-04-27'),
(185, 19, 'male', 'healed', 'RS', 'GOR Bekasi', '2021-05-28'),
(186, 33, 'male', 'healed', 'MN', 'GOR Bekasi', '2021-04-28'),
(187, 41, 'male', 'healed', 'MN', 'GOR Bekasi', '2021-04-28'),
(188, 35, 'male', 'healed', 'GH', 'Rumah', '2021-04-28'),
(189, 31, 'female', 'healed', 'TU', 'Rumah', '2021-05-28'),
(190, 23, 'female', 'healed', 'X', 'Rumah', '2021-05-28'),
(191, 35, 'female', 'healed', 'Z', 'Rumah', '2021-04-29'),
(192, 24, 'male', 'healed', 'Z', 'GOR Bekasi', '2021-05-29'),
(193, 23, 'male', 'healed', 'Y', 'GOR Bekasi', '2021-04-30'),
(194, 41, 'male', 'healed', 'RS', 'GOR Bekasi', '2021-05-01'),
(195, 35, 'female', 'healed', 'MN', 'GOR Bekasi', '2021-05-02'),
(196, 38, 'female', 'healed', 'PQ', 'RSUD Kota Bekasi', '2021-05-03'),
(197, 21, 'female', 'healed', 'X', 'RSUD Kota Bekasi', '2021-05-04'),
(198, 26, 'male', 'healed', 'X', 'Rumah', '2021-05-04'),
(199, 29, 'female', 'healed', 'PQ', 'Rumah', '2021-05-05'),
(200, 27, 'male', 'healed', 'JKL', 'Rumah', '2021-05-06'),
(201, 31, 'female', 'healed', 'GH', 'Rumah', '2021-05-07'),
(202, 33, 'male', 'healed', 'MN', 'Rumah', '2021-05-08');

-- --------------------------------------------------------

--
-- Table structure for table `hotlines`
--

CREATE TABLE `hotlines` (
  `hl_id` int(11) NOT NULL,
  `hl_number` varchar(15) NOT NULL,
  `hl_name` varchar(75) NOT NULL,
  `hl_img` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotlines`
--

INSERT INTO `hotlines` (`hl_id`, `hl_number`, `hl_name`, `hl_img`) VALUES
(25, '08121212121', 'Ibu Marla', '3hWbyvFjBK.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `msg_id` int(11) NOT NULL,
  `msg_name` varchar(75) NOT NULL,
  `msg_email` varchar(55) NOT NULL,
  `msg_text` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `data_global`
--
ALTER TABLE `data_global`
  ADD PRIMARY KEY (`dg_id`);

--
-- Indexes for table `data_lokal`
--
ALTER TABLE `data_lokal`
  ADD PRIMARY KEY (`dl_id`);

--
-- Indexes for table `hotlines`
--
ALTER TABLE `hotlines`
  ADD PRIMARY KEY (`hl_id`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`msg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_global`
--
ALTER TABLE `data_global`
  MODIFY `dg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `data_lokal`
--
ALTER TABLE `data_lokal`
  MODIFY `dl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `hotlines`
--
ALTER TABLE `hotlines`
  MODIFY `hl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
