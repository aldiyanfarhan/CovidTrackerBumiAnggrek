            <div class="col-md-3 col-lg-3 shadow sidebar">
                <div class="title">
                    <h5 class="notosans font-weight-bold"><a href="<?php echo base_url(); ?>" target="_blank">Covid-19 Tracker</a></h5>
                    <p>Admin Page <small><em><a href="<?php echo base_url('admin/logout'); ?>">Logout</a></em></small></p>
                </div>
                <div style="width:100%;height:1px;background-color:rgba(255,255,255,0.3);margin-bottom:15px"></div>
                <div class="body">
                    <p style="font-size:11px;margin-bottom:8px;padding:0 15px">MENU LINKS</p>
                    <ul>
                        <li><a href="<?php echo base_url('admin/data-indonesia'); ?>"><i class="fa fa-hospital-user"></i>Covid data Indonesia</a></li>
                        <li><a href="<?php echo base_url('admin/data-global'); ?>"><i class="fa fa-hospital-user"></i>Covid data by Country</a></li>
                        <li><a href="<?php echo base_url('admin/hotlines'); ?>"><i class="fa fa-phone-square"></i>Hotlines</a></li>
                        <li><a href="<?php echo base_url('admin/pesan'); ?>"><i class="fa fa-envelope"></i>Pesan</a></li>
                    </ul>
                </div>
            </div>