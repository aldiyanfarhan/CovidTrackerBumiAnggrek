        <footer>
            <div class="container text-center">
                <h4 class="notosans">Covid-19 Tracker</h4>
                <p style="font-size:13px;margin-bottom:0">Made with <i class="fa fa-heart"></i> by Kelompok 15 IF-42-07</p>
            </div>
        </footer>