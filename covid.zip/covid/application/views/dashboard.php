<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('headscripts'); ?>
</head>
<body>

    <div class="page">
<?php $this->load->view('navbar'); ?>
        <div class="container" style="margin-top:60px;margin-bottom:15px">
            <div class="text-center">
                <h1>CORONA TRACKER</h1>
                <p style="margin-top:20px;font-size:19px">Coronavirus Indonesia Live Data</p>
            </div>
            <!-- row 1 open -->
            <div class="row card-row" style="margin-top:60px">
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card card-banner text-white bg-primary mb-3 shadow">
                        <div class="card-body homecard">
                            <p>TOTAL POSITIF</p>
                            <h3>---</h3>
                            <p>ORANG</p>
                        </div>
                        <i class="fal fa-bed fa-4x"></i>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card card-banner text-white bg-warning mb-3 shadow">
                        <div class="card-body homecard">
                            <p>TOTAL DALAM PERAWATAN</p>
                            <h3>---</h3>
                            <p>ORANG</p>
                        </div>
                        <i class="fal fa-search-minus fa-4x"></i>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card card-banner text-white bg-success mb-3 shadow">
                        <div class="card-body homecard">
                            <p>TOTAL SEMBUH</p>
                            <h3>---</h3>
                            <p>ORANG</p>
                        </div>
                        <i class="fal fa-heart fa-4x"></i>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card card-banner text-white bg-danger mb-3 shadow">
                        <div class="card-body homecard">
                            <p>TOTAL MENINGGAL</p>
                            <h3>---</h3>
                            <p>ORANG</p>
                        </div>
                        <i class="fal fa-heart-broken fa-4x"></i>
                    </div>
                </div>
                <!-- <div class="col text-center">
                    <p style="margin-top:16px;font-size:13px">Sumber data : Kementerian Kesehatan & JHU. Update terakhir : 27 Maret 2020 03:35:09 WIB</p>
                </div> -->
            </div>
            <!-- row 1 end -->
            <div class="row statistik" style="margin-top:6px">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xl-16">
                    <div class="card noborder shadow">
                        <div class="card-header bg-white">
                            <h4 class="card-title notosans"><strong>Statistik Covid19 30 Hari Terakhir</strong></h4>
                        </div>
                        <div class="card-body">
                            <canvas id="chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row global" style="margin-top:20px">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xl-16">
                    <div class="card noborder shadow">
                        <div class="card-header bg-white">
                            <h4 class="card-title notosans"><strong>Data Covid19 per Provinsi</strong></h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover global-table">
                                    <thead>
                                        <tr>
                                            <th>NO.</th>
                                            <th>Provinsi</th>
                                            <th>Positif</th>
                                            <th>Sembuh</th>
                                            <th>Meninggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5">Memuat..</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $this->load->view('footer'); ?>
    </div>

<?php $this->load->view('bottomscripts'); ?>
    <script type="text/javascript" src="<?php echo base_url('assets/js/chart.js'); ?>"></script>
    <script type="text/javascript">

        var uri = '<?php echo base_url(); ?>';

        var charts = {labels: [], datas: []};

        $.get('https://indonesia-covid-19.mathdro.id/api', function(response) {
            let active = response.jumlahKasus - response.sembuh - response.meninggal
            $($('.card-body.homecard')[0]).find('h3').text(response.jumlahKasus);
            $($('.card-body.homecard')[1]).find('h3').text(response.perawatan);
            $($('.card-body.homecard')[2]).find('h3').text(response.sembuh);
            $($('.card-body.homecard')[3]).find('h3').text(response.meninggal);
        });

        $.get('https://indonesia-covid-19.mathdro.id/api/provinsi', function(response) {
            $('.global-table').find('tbody').html('');
            for (let i = 0; i < response.data.length - 1; i++) {
                $('.global-table').find('tbody').append('<tr>' +
                        '<td>' + (i + 1) + '</td>' +
                        '<td>' + response.data[i].provinsi + '</td>' +
                        '<td>' + response.data[i].kasusPosi + '</td>' +
                        '<td>' + response.data[i].kasusSemb + '</td>' +
                        '<td>' + response.data[i].kasusMeni + '</td>' +
                    '</tr>')
            }
        });
        
        $.get('https://indonesia-covid-19.mathdro.id/api/harian', function(response) {
            let i = response.data.length - 30;
            const monthNames = ["Jan", "Feb", "Mart", "Apr", "Mei", "Jun",
                "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
            ];
            for (let j = i; j < response.data.length; j++) {
                let d = new Date(response.data[j].tanggal);
                let date = d.getDate() + ' ' + monthNames[d.getMonth()];
                charts['labels'].push(date);
                charts['datas'].push(response.data[j].jumlahKasusKumulatif);
            }
            drawChart(charts['labels'], charts['datas']);
        });

    </script>
</body>
</html>